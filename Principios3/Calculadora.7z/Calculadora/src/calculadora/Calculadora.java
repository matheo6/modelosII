/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author Administrador
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calculator calculadora = new Calculator();
        System.out.println(calculadora.sumar(2, 3));
        System.out.println(calculadora.diviri(2, 3));
        System.out.println(calculadora.multiplicar(2, 3));
        System.out.println(calculadora.restar(2, 3));
    }
   
    
}
