package calculadora;

public class Calculator {
    private Operation sumador;
    private Operation restador;
    private Operation multiplicador;
    private Operation divisor;

    public Calculator() {
        this.sumador = new Add();
        this.restador = new Substract();
        this.multiplicador = new Multiply();
        this.divisor = new Divide();
    }
    public float multiplicar(float a, float b){
        
        return multiplicador.operation(a, b);
    }
    public float diviri(float a, float b){
        if(b!=0)
            return divisor.operation(a, b);
        else
            return 0;
    }
    public float sumar(float a, float b){
        
        return sumador.operation(a, b);
    }
    public float restar(float a, float b){
        
        return restador.operation(a, b);
    }
}
